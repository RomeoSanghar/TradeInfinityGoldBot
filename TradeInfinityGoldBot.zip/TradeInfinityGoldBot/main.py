"""
TradeInfinityGoldBot – Telegram XAUUSD signal publisher + live monitor.
Entry point for Replit / local run.

Preserves existing /test command behaviour.
Secrets are read only from environment / Replit Secrets.
"""
from __future__ import annotations

import logging
import sys
from datetime import time as dt_time

from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
)

from config import Config
from db.models import TradeRepository
from services.market_data import MarketDataService
from bot.handlers import (
    cmd_start,
    cmd_help,
    cmd_test,
    cmd_signal,
    cmd_status,
    cmd_trades,
    cmd_close,
    cmd_breakeven,
    cmd_market,
    monitor_job,
    daily_quote_job,
)

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("TradeInfinity")


def build_app(config: Config) -> Application:
    repo = TradeRepository(config.db_path)
    market = MarketDataService(
        api_key=config.twelve_data_api_key,
        symbol=config.symbol,
        stale_seconds=config.stale_quote_seconds,
    )

    app = (
        Application.builder()
        .token(config.telegram_bot_token)
        .build()
    )

    app.bot_data["config"] = config
    app.bot_data["repo"] = repo
    app.bot_data["market"] = market

    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("test", cmd_test))
    app.add_handler(CommandHandler("signal", cmd_signal))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("trades", cmd_trades))
    app.add_handler(CommandHandler("close", cmd_close))
    app.add_handler(CommandHandler("breakeven", cmd_breakeven))
    app.add_handler(CommandHandler("market", cmd_market))

    # Jobs – only schedule once
    jq = app.job_queue
    if jq is not None:
        # Live monitoring
        if market.is_configured:
            jq.run_repeating(
                monitor_job,
                interval=config.poll_interval_seconds,
                first=10,
                name="monitor_xau",
            )
            logger.info(
                "Monitoring job scheduled every %ss", config.poll_interval_seconds
            )
        else:
            logger.warning(
                "TWELVE_DATA_API_KEY missing – live monitoring DISABLED. "
                "Signals can still be published; price will not be tracked."
            )

        # Daily motivational quote (timezone-aware)
        try:
            import pytz
            tz = pytz.timezone(config.quote_timezone)
            quote_time = dt_time(
                hour=config.motivational_quote_hour,
                minute=config.motivational_quote_minute,
                tzinfo=tz,
            )
            jq.run_daily(
                daily_quote_job,
                time=quote_time,
                name="daily_quote",
            )
            logger.info(
                "Daily quote scheduled at %02d:%02d %s",
                config.motivational_quote_hour,
                config.motivational_quote_minute,
                config.quote_timezone,
            )
        except Exception as e:
            logger.warning("Could not schedule daily quote: %s", e)
    else:
        logger.warning("JobQueue not available – monitoring and quotes disabled")

    return app


def main() -> None:
    try:
        config = Config.from_env()
    except ValueError as e:
        logger.error("%s", e)
        sys.exit(1)

    missing = config.missing_secrets()
    if missing:
        logger.warning("Missing configuration (bot will start but some features disabled):")
        for m in missing:
            logger.warning("  – %s", m)
        logger.warning(
            "Add the missing keys in Replit Secrets (Tools → Secrets) then restart."
        )

    logger.info("Starting TradeInfinityGoldBot")
    logger.info(config.status_report())

    app = build_app(config)
    # drop_pending_updates avoids replaying old commands after restart
    app.run_polling(drop_pending_updates=True, allowed_updates=["message"])


if __name__ == "__main__":
    main()
