# TradeInfinityGoldBot (Standalone)

Telegram XAUUSD signal publisher + live trade monitor.  
**Replit / Termux ki zaroorat nahi.**

Yeh bot kabhi real broker order nahi lagata. Sirf signal publish + status monitor karta hai.

---

## Sab se aasan free options

### Option 1 — Apne Laptop / PC pe (bilkul free)

1. Python 3.10+ install karo (python.org)
2. Project unzip karo
3. Terminal / CMD mein:

```bash
cd TradeInfinityGoldBot
pip install -r requirements.txt
```

4. `.env` file banao (`.env.example` ko copy karke):

```env
TELEGRAM_BOT_TOKEN=apka_bot_token
TELEGRAM_GROUP_ID=-100xxxxxxxxxx
ADMIN_TELEGRAM_ID=apka_user_id
TWELVE_DATA_API_KEY=apka_twelve_data_key
```

5. Run:

```bash
python main.py
```

Bot chalna shuru ho jayega. Laptop band mat karna (warna bot ruk jayega).

---

### Option 2 — Railway.app (recommended free cloud)

1. https://railway.app pe jao → GitHub se login
2. New Project → Deploy from GitHub (ya ZIP upload)
3. Variables / Secrets mein yeh add karo:

```
TELEGRAM_BOT_TOKEN
TELEGRAM_GROUP_ID
ADMIN_TELEGRAM_ID
TWELVE_DATA_API_KEY
```

4. Start command: `python main.py`
5. Deploy. Free tier pe chalega (limits ke andar).

---

### Option 3 — Render.com free

1. https://render.com → New → Web Service
2. Repo connect karo ya ZIP upload
3. Build: `pip install -r requirements.txt`
4. Start: `python main.py`
5. Environment variables mein secrets add karo
6. Free tier choose karo

---

## Secrets kaise lein

| Secret | Kahan se milega |
|--------|-----------------|
| `TELEGRAM_BOT_TOKEN` | @BotFather se |
| `ADMIN_TELEGRAM_ID` | @userinfobot se apna ID |
| `TELEGRAM_GROUP_ID` | Bot ko group mein add karo → message bhejo → `https://api.telegram.org/bot<TOKEN>/getUpdates` se chat id copy karo (negative number) |
| `TWELVE_DATA_API_KEY` | twelvedata.com pe free account banao |

---

## Bot commands (Telegram se iPhone pe)

- `/test` — check
- `/help`
- `/signal XAUUSD BUY 2650.50 2640.00 2675.00`
- `/signal XAUUSD SELL 2650.50 2660.00 2625.00`
- `/status`
- `/trades`
- `/close TI-XXXXXXXX`
- `/breakeven TI-XXXXXXXX`
- `/market` — Twelve Data connected hai ya nahi

Sirf ADMIN_TELEGRAM_ID wala user yeh commands use kar sakta hai.

---

## Important

- Live monitoring tabhi kaam karega jab `/market` successful quote dikhaye.
- External price aapke broker se different ho sakti hai.
- Bot real order nahi lagata.
- Free Twelve Data limit: 8 calls/min, 800/day. Default poll 60 seconds hai.

---

Agar aap bata dein ke aap **laptop** pe chalana chahte ho ya **Railway/Render**, to main us hisaab se exact steps aur files adjust kar dunga.
